# SunLite Showcase — a GreenMarine v1 shaderpack

SunLite is a self-contained **resource pack** (no GreenMarine source edits, no
code changes to the mod) that demonstrates the GreenMarine shader platform and
adds real **screen-space sun (and moon) shadows** plus a full post chain.

It exercises almost every declared capability of the GreenMarine v1 ABI:
Lua scripting, owned point lights, the lightmap stage, scaled passes, quality
gating, capability gating with fallbacks, declaration-ordered parameters and
precompiled fragment SPIR-V on Vulkan.

## What it adds visually

- **Sun shadows by day** — a directional screen-space march that fully
  darkens surfaces the sun cannot reach, with a soft penumbra.
- **Faint moon shadows at night** — same technique, weaker, using the moon as
  the light source.
- **Custom lightmap** — a warmed, ambient-lifted replacement of the vanilla
  16x16 lightmap.
- **Bloom** (half resolution, High/Ultra only).
- **Chromatic fringe** (0.75 resolution, High/Ultra, Vulkan only; a plain
  fallback runs on OpenGL).
- **Contact ambient occlusion**, exposure/saturation grading and vignette.
- **Two scripted owned point lights** (a fixed warm lamp and a swinging cool
  beacon) plus a blinking third one, driven by the Lua API.

## Feature → capability map

| GreenMarine v1 feature | Where in this pack |
| --- | --- |
| Lua `update(frame)` per tick | `greenmarine/scripts/full.lua` |
| `marine.uniform(...)` (validated ranges) | all passes share 12 params |
| `marine.light` / `marine.remove_light` | slots 0, 1, 2 in the script |
| `frame.quality`, `frame.day`, `frame.time`, `frame.camera` | script gates cost / positions lights |
| `frame.capabilities.spirv` | script raises shadow length on Vulkan |
| Lightmap stage | `lightmap` pass, `shaders/core/lightmap.fsh` |
| Scaled scene passes | `bloom` at scale 0.5 |
| `minQuality` gating | bloom + fringe need High+ |
| `requires` + `fallback` | `fringe` requires Vulkan, falls back to `fringe_plain` |
| Declaration-ordered params + `MarineFrame` std140 | `marineParameter(i)` in all shaders |
| Includes | `#include <sunlite:frame.glsl>` (self-contained copy) |
| Precompiled SPIR-V | `composite` pass ships `greenmarine/spirv/composite.spv` |
| Depth reconstruction / view matrices | sun shadow march in `composite.fsh` |
| Detail-preserving final composite | composite blends `SceneSampler` + `ColorSampler` |

## Installation

Requirements: Minecraft **26.3**, Fabric Loader **0.19.5+**, Java **25** and the
GreenMarine **0.2** prototype jar installed as a Fabric mod.

1. Put `sunlite-showcase-0.1.0.zip` into your instance's
   `resourcepacks/` folder (or unzip it there and use the folder; both work).
   Confirm it appears in the Minecraft resource pack list.
2. Launch the game and reload resources (**F3+T**) so GreenMarine discovers the
   pack manifest.
3. Open the pack selector with **F6**, choose **SunLite Showcase** and set the
   quality to **High** or **Ultra** (the bloom/fringe passes require High+;
   Low/Medium still get sun shadows at reduced cost).
4. **F8** toggles the world effects. The hand and HUD keep ordinary rendering.
   **F7** still places GreenMarine's own demo light if you want one more.

Alternatively preselect it in `config/greenmarine-shaders.json` before launch:

```json
{
  "pack": "sunlite:full",
  "quality": "high",
  "rays": "auto",
  "profiling": false
}
```

`rays` matters for point-light voxel shadows (F6 → Auto/Voxel), which are
independent of the pack's own screen-space sun shadows.

## Pack structure

```
pack.mcmeta
assets/sunlite/
  greenmarine/packs/full.json          manifest (schema 1)
  greenmarine/scripts/full.lua         per-tick script
  greenmarine/spirv/composite.spv      precompiled composite (Vulkan 1.1)
  shaders/include/frame.glsl           reusable include
  shaders/core/lightmap.fsh            lightmap stage
  shaders/core/bloom.fsh               half-res bloom (High+)
  shaders/core/fringe.fsh              chromatic fringe (Vulkan, High+)
  shaders/core/fringe_plain.fsh        fallback when Vulkan is unavailable
  shaders/core/composite.fsh           sun/moon shadows + AO + grading + SPIR-V
```

## Parameters (tunable in `full.lua` / manifest defaults)

`exposure`, `saturation`, `warmth`, `ambient`, `sunStrength`, `shadowLength`
(march steps 4–64), `softness`, `bloomStrength`, `moonStrength`, `sunAzimuth`,
`ao`, `vignette`.

## Notes and honest limits

- Sun direction is **approximated** from the day fraction and a fixed `sunAzimuth`;
  it may not coincide exactly with the rendered sun disc. The shadow march is a
  screen-space effect: occluders outside the view frustum, transparency and
  partial blocks are not perfectly handled, and contact shadows near the camera
  are the most reliable.
- At **Low** quality the script disables sun/moon shadows and AO entirely.
- On **Vulkan** the composite pass prefers `composite.spv`; if reflection or
  validation ever fails, GreenMarine automatically falls back to the GLSL
  source. OpenGL always uses GLSL.
- The scripted lights are demo content; delete the `marine.light` lines and
  `local lamp` block if you only want the effects.
- GreenMarine is a post-processing/lightmap platform: this pack deliberately
  does **not** replace Minecraft's geometry, shadow-mapping or material
  pipelines.

Rebuild the included SPIR-V after editing `composite.fsh`:

```sh
glslangValidator -V --target-env vulkan1.1 --auto-map-bindings --auto-map-locations \
  -S frag -o composite.spv composite.fsh
spirv-val --target-env vulkan1.1 composite.spv
spirv-opt -O composite.spv -o composite-opt.spv
spirv-val --target-env vulkan1.1 composite-opt.spv
```