#version 330
#extension GL_ARB_separate_shader_objects : require
layout(std140) uniform MarineFrame {
    vec4 Frame;                 // pass width, height, time seconds, day fraction
    vec4 Context;               // depth zero-to-one flag, quality enum, ray enum, reserved
    mat4 InverseProjection;     // actual submitted world projection, inverted
    mat4 InverseViewRotation;   // camera view rotation, inverted
    vec4 Parameters[8];         // 32 declaration-ordered float slots
};
uniform sampler2D ColorSampler;
uniform sampler2D SceneSampler;
uniform sampler2D DepthSampler;
layout(location=0) in vec2 texCoord;
layout(location=0) out vec4 fragColor;

// Keep this file self-contained so it also compiles cleanly to SPIR-V.
float marineParameter(int index) { return Parameters[index / 4][index % 4]; }

vec3 viewPosition(vec2 uv, float depth) {
    float z = Context.x > 0.5 ? depth : depth * 2.0 - 1.0;
    vec4 p = InverseProjection * vec4(uv * 2.0 - 1.0, z, 1.0);
    return p.xyz / p.w;
}

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

void main() {
    vec2 uv = texCoord;
    vec3 color = texture(SceneSampler, uv).rgb;
    float depth = texture(DepthSampler, uv).r;
    if (depth > 0.0005) {
        vec3 center = viewPosition(uv, depth);

        // Approximate sun direction from the day fraction (0 = sunrise at 06:00).
        float theta = Frame.w * 6.28318530718;
        float elev = sin(theta);
        float horiz = sqrt(max(0.0, 1.0 - elev * elev));
        float azimuth = marineParameter(9);
        vec3 sunWorld = normalize(vec3(horiz * cos(azimuth), elev, horiz * sin(azimuth)));
        bool day = elev > 0.0;
        vec3 dirWorld = day ? sunWorld : -sunWorld;
        float strength = day ? marineParameter(4) : marineParameter(8);

        if (strength > 0.002) {
            mat3 worldToView = mat3(transpose(InverseViewRotation));
            vec3 sunView = normalize(worldToView * dirWorld);
            mat4 Projection = inverse(InverseProjection);

            int steps = clamp(int(marineParameter(5)), 4, 64);
            float reach = 6.0 + length(center) * 0.05;
            float stepLen = reach / float(steps);
            float jitter = hash12(uv * Frame.xy + fract(Frame.z) * 175.3);
            float shade = 1.0;
            float tStart = jitter * stepLen;

            for (int i = 0; i < steps; i++) {
                float t = tStart + (float(i) + 0.5) * stepLen;
                vec3 samplePos = center + sunView * t;
                vec4 clip = Projection * vec4(samplePos, 1.0);
                if (clip.w <= 1.0e-4) break;
                vec3 ndc = clip.xyz / clip.w;
                bool insideZ = Context.x > 0.5
                    ? (ndc.z >= 0.0 && ndc.z <= 1.0)
                    : (ndc.z >= -1.0 && ndc.z <= 1.0);
                if (!insideZ) break;
                vec2 shadowUv = ndc.xy * 0.5 + 0.5;
                if (shadowUv.x < 0.0 || shadowUv.x > 1.0 || shadowUv.y < 0.0 || shadowUv.y > 1.0) break;

                float sampleDepth = texture(DepthSampler, shadowUv).r;
                if (sampleDepth < 0.0005) continue;
                vec3 sampleGeom = viewPosition(shadowUv, sampleDepth);
                vec3 gap = sampleGeom - center;
                float along = dot(gap, sunView);
                float offset = length(gap - sunView * along);
                float tolerance = marineParameter(6) * stepLen;
                if (along >= 0.0 && along <= t && offset < tolerance) {
                    float penumbra = 1.0 - smoothstep(0.0, stepLen, t - along);
                    shade = min(shade, 1.0 - strength * penumbra);
                }
            }
            color *= shade;
        }
    }

    // Reduced-resolution effect passes (bloom, fringe) arrive through ColorSampler.
    ivec2 colorSize = textureSize(ColorSampler, 0);
    ivec2 sceneSize = textureSize(SceneSampler, 0);
    if (colorSize.x < sceneSize.x) {
        vec3 enhance = texture(ColorSampler, uv).rgb;
        color += max(enhance - vec3(0.30), vec3(0.0)) * marineParameter(7) * 2.5;
    }

    // Screen-space contact ambient occlusion.
    float ao = marineParameter(10);
    if (ao > 0.001 && depth > 0.0005) {
        vec2 pixel = 1.0 / vec2(sceneSize);
        vec3 center = viewPosition(uv, depth);
        float occlusion = 0.0;
        for (int i = 0; i < 8; i++) {
            float angle = float(i) * 0.78539816339745;
            vec2 neighborUv = uv + vec2(cos(angle), sin(angle)) * pixel * 4.0;
            float neighborDepth = texture(DepthSampler, neighborUv).r;
            if (neighborDepth > 0.0005) {
                vec3 neighbor = viewPosition(neighborUv, neighborDepth);
                float separation = neighbor.z - center.z;
                occlusion += smoothstep(0.03, 0.15, separation)
                    * (1.0 - smoothstep(0.2, 1.0, length(neighbor - center)));
            }
        }
        color *= 1.0 - ao * occlusion / 8.0;
    }

    // Colour grading.
    color *= marineParameter(0);
    float luma = dot(color, vec3(0.2126, 0.7152, 0.0722));
    color = mix(vec3(luma), color, marineParameter(1));

    // Gentle vignette.
    if (marineParameter(11) > 0.001) {
        vec2 d = uv - 0.5;
        color *= clamp(1.0 + marineParameter(11) * (dot(d, d) * 2.7 - 0.6), 0.0, 1.10);
    }

    fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}