#version 330
#extension GL_ARB_separate_shader_objects : require
#extension GL_GOOGLE_include_directive : require
#include <sunlite:frame.glsl>
uniform sampler2D ColorSampler;
layout(location=0) in vec2 texCoord;
layout(location=0) out vec4 fragColor;

void main() {
    vec3 light = texture(ColorSampler, texCoord).rgb;
    float warmth = marineParameter(2);
    vec3 tint = vec3(1.0, 1.0 - warmth * 0.35, 1.0 - warmth * 0.70);
    vec3 room = vec3(marineParameter(3)) * (0.55 + 0.45 * (1.0 - texCoord.y));
    fragColor = vec4(clamp(light * tint + room, 0.0, 1.0), 1.0);
}