#version 330
#extension GL_ARB_separate_shader_objects : require
uniform sampler2D ColorSampler;
uniform sampler2D SceneSampler;
layout(location=0) in vec2 texCoord;
layout(location=0) out vec4 fragColor;

void main() {
    vec3 source = texture(ColorSampler, texCoord).rgb;
    vec2 pixel = 1.0 / vec2(textureSize(SceneSampler, 0));
    float off = 0.0012 * (pixel.x * textureSize(SceneSampler, 0).x);
    vec3 red = texture(SceneSampler, texCoord + vec2(off, 0.0)).rgb;
    vec3 blue = texture(SceneSampler, texCoord - vec2(off, 0.0)).rgb;
    vec3 fringe = vec3(red.r, source.g, blue.b) - source;
    fragColor = vec4(source + fringe * 0.8, 1.0);
}