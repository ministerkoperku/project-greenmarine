#ifndef SUNLITE_FRAME_V1
#define SUNLITE_FRAME_V1
layout(std140) uniform MarineFrame {
    vec4 Frame;                 // pass width, height, time seconds, day fraction
    vec4 Context;               // depth zero-to-one flag, quality enum, ray enum, reserved
    mat4 InverseProjection;     // actual submitted world projection, inverted
    mat4 InverseViewRotation;   // camera view rotation, inverted
    vec4 Parameters[8];         // 32 declaration-ordered float slots
};
float marineParameter(int index) { return Parameters[index / 4][index % 4]; }
vec3 marineViewPosition(vec2 uv, float depth) {
    float z = Context.x > 0.5 ? depth : depth * 2.0 - 1.0;
    vec4 p = InverseProjection * vec4(uv * 2.0 - 1.0, z, 1.0);
    return p.xyz / p.w;
}
vec3 marineRelativeWorldPosition(vec2 uv, float depth) {
    return (InverseViewRotation * vec4(marineViewPosition(uv, depth), 0.0)).xyz;
}
#endif