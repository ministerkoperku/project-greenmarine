local lamp = { x = 0.0, y = 3.0, z = 0.0 }
local fixed = false

function update(frame)
    local day = frame.day
    local t = frame.time
    local quality = frame.quality
    local rise = math.sin(day * 6.28318530718)

    marine.uniform("warmth", 0.12 + 0.04 * math.sin(day * 6.28318530718))
    marine.uniform("ambient", 0.02 + 0.01 * math.max(0.0, rise))
    marine.uniform("saturation", 1.10)
    marine.uniform("sunAzimuth", 0.0)
    marine.uniform("softness", 0.7)

    if quality == "low" then
        marine.uniform("sunStrength", 0.0)
        marine.uniform("moonStrength", 0.0)
        marine.uniform("ao", 0.0)
        marine.uniform("vignette", 0.0)
    elseif quality == "medium" then
        marine.uniform("sunStrength", 0.55)
        marine.uniform("shadowLength", 16.0)
        marine.uniform("moonStrength", 0.18)
        marine.uniform("ao", 0.25)
        marine.uniform("vignette", 0.4)
    else
        local strike = marine.mix(0.45, 0.85, marine.clamp(rise * 1.8, 0.0, 1.0))
        marine.uniform("sunStrength", rise > 0.02 and strike or 0.0)
        marine.uniform("moonStrength", rise < -0.02 and 0.30 or 0.0)
        marine.uniform("shadowLength", 22.0)
        if frame.capabilities.spirv then
            marine.uniform("shadowLength", 26.0)
        end
        marine.uniform("ao", quality == "high" and 0.35 or 0.45)
        marine.uniform("vignette", 0.5)
    end

    if not fixed then
        lamp.x = frame.camera.x + 6.0
        lamp.y = frame.camera.y + 3.0
        lamp.z = frame.camera.z + 6.0
        fixed = true
    end
    marine.light(0, lamp.x, lamp.y, lamp.z, 1.0, 0.45, 0.2, 7.0, 1.35)

    local sx = frame.camera.x + 6.0 * math.sin(t * 0.5)
    local sy = frame.camera.y + 2.5 + math.sin(t * 0.9) * 0.5
    local sz = frame.camera.z + 6.0 * math.cos(t * 0.4)
    marine.light(1, sx, sy, sz, 0.35, 0.6, 1.0, 5.0, 0.8)

    if math.floor(t) % 30 >= 15 then
        marine.remove_light(2)
    else
        marine.light(2, frame.camera.x + 2.0, frame.camera.y + 4.0, frame.camera.z, 1.0, 0.3, 0.4, 4.0, 0.6)
    end
end