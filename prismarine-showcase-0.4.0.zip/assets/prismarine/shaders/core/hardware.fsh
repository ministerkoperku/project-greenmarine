#version 330
#extension GL_ARB_separate_shader_objects : require
#extension GL_GOOGLE_include_directive : require
#include <greenmarine:frame.glsl>
#include <greenmarine:rays.glsl>
uniform sampler2D ColorSampler;
uniform sampler2D SceneSampler;
uniform sampler2D DepthSampler;
layout(location=0) in vec2 texCoord;
layout(location=0) out vec4 fragColor;
float luminance(vec3 color) { return dot(color, vec3(0.2126, 0.7152, 0.0722)); }
void main() {
    vec4 effect = texture(ColorSampler, texCoord);
    if (!marineHardwareRayReady()) { fragColor = vec4(effect.rgb, 1.0); return; }
    float depth = texture(DepthSampler, texCoord).r;
    vec4 surface = texture(RayNormalDepth, texCoord);
    vec4 albedo = texture(RayAlbedo, texCoord);
    if (albedo.a < 0.5 || depth <= 0.0 || abs(surface.w - depth) > max(0.00015, depth * 0.015)) {
        fragColor = vec4(effect.rgb, 1.0); return;
    }
    vec3 light = max(texture(RayLighting, texCoord).rgb, vec3(0.0));
    vec4 scene = texture(SceneSampler, texCoord);
    float albedoLuma = max(luminance(albedo.rgb), 0.02);
    float irradianceRay = luminance(light) / albedoLuma;
    float irradianceRaster = luminance(pow(max(scene.rgb, vec3(0.0)), vec3(2.2))) / albedoLuma;
    float visibility = clamp(irradianceRay / max(irradianceRaster, 0.02), 0.0, 1.0);
    float shadow = mix(1.0, visibility, marineParameter(6));
    vec3 add = light * marineParameter(5);
    fragColor = vec4(effect.rgb + add, shadow);
}
