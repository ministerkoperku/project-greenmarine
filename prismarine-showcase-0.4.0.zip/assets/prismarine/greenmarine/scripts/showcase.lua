-- Prismarine Showcase: parameters, quality gating and RT-gated light handles.
-- Edited through F6; the native ray paths consume the same declared parameters.
local lightsPlaced = false

local function placeLights(frame)
    local t = frame.time
    marine.light(0, frame.camera.x + math.cos(t) * 4.0, frame.camera.y + 2.0, frame.camera.z + math.sin(t) * 4.0,
        1.00, 0.85, 0.55, 6.0, 2.5)
    marine.light(1, frame.camera.x + 6.0, frame.camera.y + 1.5, frame.camera.z - 6.0,
        0.40, 0.70, 1.00, 5.0, 1.8)
    lightsPlaced = true
end

local function clearLights()
    marine.remove_light(0)
    marine.remove_light(1)
    lightsPlaced = false
end

function update(frame)
    marine.uniform("warmth", marine.clamp(0.10 + 0.03 * math.sin(frame.day * 6.2831853), 0.0, 1.0))
    marine.uniform("bloom", frame.quality == "low" and 0.0 or 0.22)
    marine.uniform("blend", marine.mix(0.45, 0.62, frame.quality == "ultra" and 1.0 or 0.0))

    local rayLighting = frame.capabilities.voxel_rt or frame.capabilities.hardware_rt
    if rayLighting and frame.rays ~= "off" then
        placeLights(frame)
    elseif lightsPlaced then
        clearLights()
    end
end
