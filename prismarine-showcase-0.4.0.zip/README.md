# Prismarine Showcase

A third-party GreenMarine shaderpack that exercises the current shaderpack API:
multi-pass scheduling, per-pass render scale and `rgba16f` format, requirement
gating with fallbacks (`voxel_rt` and `hardware_rt`), a SPIR-V fragment, a Lua
script, and every sampler exposed to scene passes.

## Passes

| Pass       | Stage    | Requires     | Fallback                  | Scale | Format  | Notes                          |
|------------|----------|--------------|---------------------------|-------|---------|--------------------------------|
| `lightmap` | lightmap | none         | -                         | 1.0   | scene   | day/warmth/ambient tint        |
| `voxel`    | scene    | `voxel_rt`   | `prismarine:core/zero`    | 0.5   | rgba16f | voxel hemisphere GI            |
| `hardware` | scene    | `hardware_rt`| `prismarine:core/pass`    | 0.5   | rgba16f | RT illumination + soft shadow  |
| `bloom`    | scene    | none         | -                         | 0.5   | rgba16f | bright pass, keeps GI          |
| `compose`  | scene    | none         | -                         | 1.0   | scene   | tonemap, grade, fog, `compose.spv` |

Requirement fallbacks are exact inverses: under `hardware_rt` the voxel pass
degrades to `zero` and the RT pass runs; under `voxel_rt` the RT pass degrades
to `pass` (a copy) and preserves the voxel result.

## Parameters

`exposure`, `saturation`, `warmth`, `vignette`, `bloom`, `blend`, `shadow`,
`ambient`, `fog`, `diagnostic` (edit with F6).

Set `diagnostic` to visualize raw RT buffers: 1 albedo, 2 normal, 3 depth,
4 lighting.

## Install

1. Drop `prismarine-showcase-0.4.0.zip` into `.minecraft/resourcepacks/`.
2. Enable it in Options > Resource Packs.
3. Select **Prismarine Showcase** with F6 (GreenMarine pack selector).
4. Hardware RT requires a Vulkan device with the ray-query feature set enabled;
   set rays to `hardware`. Otherwise the pack renders and falls back cleanly.

## ABI

Sources, includes (`greenmarine:*`), script and SPIR-V all resolve through the
resource manager, so the pack needs no game files on disk. Targets shaderpack
schema 1 (`MarineFrame`, 288 bytes std140; ray/voxel bindings).
